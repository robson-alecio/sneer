package spikes.priscila.test;

import java.util.ArrayList;

public class Test3 {
	
	public static void main(String[] args){
		
		long time1=System.currentTimeMillis();
		measure(new ArrayList<String>(2000000));
		System.out.println((System.currentTimeMillis()-time1));
		
		long time=System.currentTimeMillis();
		ArrayList<String> x= new ArrayList<String>(2000000);
		
		for (int i = 1000000; i != 0; i--)
			x.add("1");
		
		System.out.println((System.currentTimeMillis()-time));

		
	}

	private static void measure(ArrayList<String> subject) {
		
		ArrayList<String> x = subject;
		for (int i = 1000000; i != 0; i--)
			x.add("1");
		
	}

}
