package spikes.priscila.test;


public class Test2 {
	
	public static void main(String[] args){
		
		
		long time=System.currentTimeMillis();
		double d = 35.89;
		double result = 0;
		int cont=10000000;
		while(cont != 0){
			 result+=(3.67 + d)/8.566;
			 cont--;
		}
		
		System.out.println((System.currentTimeMillis()-time));

		measure(d);
	}

	private static void measure(double d) {
		long time1=System.currentTimeMillis();
		double result = 0;
		int cont=10000000;
		while(cont != 0){
			 result+=(3.67 + d)/8.566;
			 cont--;
		}
		
		System.out.println((System.currentTimeMillis()-time1));
	}

}
