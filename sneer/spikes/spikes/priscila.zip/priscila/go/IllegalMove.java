/**
 * 
 */
package spikes.priscila.go;

public class IllegalMove extends Exception { private static final long serialVersionUID = 1L; }